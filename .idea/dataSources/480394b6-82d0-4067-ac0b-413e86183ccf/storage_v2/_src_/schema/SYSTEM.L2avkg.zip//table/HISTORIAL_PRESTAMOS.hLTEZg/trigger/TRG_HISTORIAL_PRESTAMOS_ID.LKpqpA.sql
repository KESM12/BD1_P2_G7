create trigger TRG_HISTORIAL_PRESTAMOS_ID
    before insert
    on HISTORIAL_PRESTAMOS
    for each row
    when (NEW.ID_HISTORIAL_PRESTAMO IS NULL)
BEGIN
    :NEW.ID_HISTORIAL_PRESTAMO := seq_historial_prestamos.NEXTVAL;
END;
/

