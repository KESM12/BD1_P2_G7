create trigger TRG_ESTADOS_PRESTAMOS_ID
    before insert
    on ESTADOS_PRESTAMOS
    for each row
    when (NEW.ID_EPRESTAMO IS NULL)
BEGIN
    :NEW.ID_EPRESTAMO := seq_estados_prestamos.NEXTVAL;
END;
/

