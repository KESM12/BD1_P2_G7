create trigger TRG_MUNICIPIOS_ID
    before insert
    on MUNICIPIOS
    for each row
    when (NEW.ID_MUNICIPIO IS NULL)
BEGIN
    :NEW.ID_MUNICIPIO := seq_municipios.NEXTVAL;
END;
/

