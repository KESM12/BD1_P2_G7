create trigger TRG_HISTORIAL_SALDOS_ID
    before insert
    on HISTORIAL_SALDOS
    for each row
    when (NEW.ID_HISTORIAL IS NULL)
BEGIN
    :NEW.ID_HISTORIAL := seq_historial_saldos.NEXTVAL;
END;
/

