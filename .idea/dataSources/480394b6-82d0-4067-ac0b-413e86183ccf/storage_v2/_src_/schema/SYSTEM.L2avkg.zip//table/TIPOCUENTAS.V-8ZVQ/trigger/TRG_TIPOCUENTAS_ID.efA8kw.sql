create trigger TRG_TIPOCUENTAS_ID
    before insert
    on TIPOCUENTAS
    for each row
    when (NEW.ID_TIPO_CUENTA IS NULL)
BEGIN
    :NEW.ID_TIPO_CUENTA := seq_tipocuentas.NEXTVAL;
END;
/

