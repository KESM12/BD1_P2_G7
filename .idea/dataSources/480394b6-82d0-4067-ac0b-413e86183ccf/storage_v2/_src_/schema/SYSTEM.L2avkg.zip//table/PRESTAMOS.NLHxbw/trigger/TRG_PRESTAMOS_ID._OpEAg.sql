create trigger TRG_PRESTAMOS_ID
    before insert
    on PRESTAMOS
    for each row
    when (NEW.ID_PRESTAMO IS NULL)
BEGIN
    :NEW.ID_PRESTAMO := seq_prestamos.NEXTVAL;
END;
/

