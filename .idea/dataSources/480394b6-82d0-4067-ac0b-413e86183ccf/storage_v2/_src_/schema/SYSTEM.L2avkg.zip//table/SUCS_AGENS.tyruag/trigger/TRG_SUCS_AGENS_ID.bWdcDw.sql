create trigger TRG_SUCS_AGENS_ID
    before insert
    on SUCS_AGENS
    for each row
    when (NEW.ID_SUC_AGEN IS NULL)
BEGIN
    :NEW.ID_SUC_AGEN := seq_sucs_agens.NEXTVAL;
END;
/

