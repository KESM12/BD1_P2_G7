create trigger TRG_TRANSACCIONES_ID
    before insert
    on TRANSACCIONES
    for each row
    when (NEW.ID_TRANSACCION IS NULL)
BEGIN
    :NEW.ID_TRANSACCION := seq_transacciones.NEXTVAL;
END;
/

