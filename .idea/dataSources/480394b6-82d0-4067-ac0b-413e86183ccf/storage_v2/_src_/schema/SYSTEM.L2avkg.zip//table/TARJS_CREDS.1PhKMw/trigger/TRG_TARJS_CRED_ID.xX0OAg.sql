create trigger TRG_TARJS_CRED_ID
    before insert
    on TARJS_CREDS
    for each row
    when (NEW.ID_TARJETA IS NULL)
BEGIN
    :NEW.ID_TARJETA := seq_tarjs_cred.NEXTVAL;
END;
/

