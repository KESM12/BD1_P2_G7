create trigger TRG_EMPLEADOS_ID
    before insert
    on EMPLEADOS
    for each row
    when (NEW.ID_EMPLEADO IS NULL)
BEGIN
    :NEW.ID_EMPLEADO := seq_empleados.NEXTVAL;
END;
/

