create trigger TRG_ROLES_ID
    before insert
    on ROLES
    for each row
    when (NEW.ID_ROL IS NULL)
BEGIN
    :NEW.ID_ROL := seq_roles.NEXTVAL;
END;
/

