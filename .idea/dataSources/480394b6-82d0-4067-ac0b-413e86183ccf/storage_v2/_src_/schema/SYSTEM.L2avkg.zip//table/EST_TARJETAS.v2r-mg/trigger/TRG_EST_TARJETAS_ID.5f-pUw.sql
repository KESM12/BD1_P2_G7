create trigger TRG_EST_TARJETAS_ID
    before insert
    on EST_TARJETAS
    for each row
    when (NEW.ID_ESTADO IS NULL)
BEGIN
    :NEW.ID_ESTADO := seq_est_tarjetas.NEXTVAL;
END;
/

