create trigger TRG_DEPARTAMENTOS_ID
    before insert
    on DEPARTAMENTOS
    for each row
    when (NEW.ID_DEPARTAMENTO IS NULL)
BEGIN
    :NEW.ID_DEPARTAMENTO := seq_departamentos.NEXTVAL;
END;
/

