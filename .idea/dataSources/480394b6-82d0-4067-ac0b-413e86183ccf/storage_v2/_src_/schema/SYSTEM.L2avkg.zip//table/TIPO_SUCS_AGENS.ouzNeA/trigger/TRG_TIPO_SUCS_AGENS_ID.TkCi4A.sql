create trigger TRG_TIPO_SUCS_AGENS_ID
    before insert
    on TIPO_SUCS_AGENS
    for each row
    when (NEW.ID_TIPO_SUC_AGEN IS NULL)
BEGIN
    :NEW.ID_TIPO_SUC_AGEN := seq_tipo_sucs_agens.NEXTVAL;
END;
/

