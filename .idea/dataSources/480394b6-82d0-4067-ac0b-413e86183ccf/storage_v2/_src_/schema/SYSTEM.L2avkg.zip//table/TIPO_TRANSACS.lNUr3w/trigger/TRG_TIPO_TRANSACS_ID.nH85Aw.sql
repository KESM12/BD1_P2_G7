create trigger TRG_TIPO_TRANSACS_ID
    before insert
    on TIPO_TRANSACS
    for each row
    when (NEW.ID_TIPO_TRAN IS NULL)
BEGIN
    :NEW.ID_TIPO_TRAN := seq_tipo_transacs.NEXTVAL;
END;
/

