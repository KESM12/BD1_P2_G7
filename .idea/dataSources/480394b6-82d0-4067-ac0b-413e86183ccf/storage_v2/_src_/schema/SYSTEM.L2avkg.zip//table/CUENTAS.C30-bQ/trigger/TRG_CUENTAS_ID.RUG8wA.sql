create trigger TRG_CUENTAS_ID
    before insert
    on CUENTAS
    for each row
    when (NEW.ID_CUENTA IS NULL)
BEGIN
    :NEW.ID_CUENTA := seq_cuentas.NEXTVAL;
END;
/

