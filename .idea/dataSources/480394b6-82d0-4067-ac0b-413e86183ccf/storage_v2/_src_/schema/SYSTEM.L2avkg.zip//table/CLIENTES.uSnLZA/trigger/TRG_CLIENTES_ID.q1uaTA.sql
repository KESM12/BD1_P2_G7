create trigger TRG_CLIENTES_ID
    before insert
    on CLIENTES
    for each row
    when (NEW.ID_CLIENTE IS NULL)
BEGIN
    :NEW.ID_CLIENTE := seq_clientes.NEXTVAL;
END;
/

