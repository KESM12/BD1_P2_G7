create trigger TRG_SEGURIDAD_ACCESO_ID
    before insert
    on SEGURIDAD_ACCESO
    for each row
    when (NEW.ID_ACCESO IS NULL)
BEGIN
    :NEW.ID_ACCESO := seq_seguridad_acceso.NEXTVAL;
END;
/

