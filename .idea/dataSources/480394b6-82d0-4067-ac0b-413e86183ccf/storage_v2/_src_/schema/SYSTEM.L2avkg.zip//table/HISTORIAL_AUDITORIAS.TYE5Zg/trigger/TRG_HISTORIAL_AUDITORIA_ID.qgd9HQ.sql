create trigger TRG_HISTORIAL_AUDITORIA_ID
    before insert
    on HISTORIAL_AUDITORIAS
    for each row
    when (NEW.ID_AUDITORIA IS NULL)
BEGIN
    :NEW.ID_AUDITORIA := seq_historial_auditoria.NEXTVAL;
END;
/

