create trigger TRG_ESTADO_FINANCIERO_ID
    before insert
    on ESTADO_FINANCIERO
    for each row
    when (NEW.ID_ESTADO IS NULL)
BEGIN
    :NEW.ID_ESTADO := seq_estado_financiero.NEXTVAL;
END;
/

