create trigger TRG_TRANSACCIONES_INTERBANCARIAS_ID
    before insert
    on TRANSACCIONES_INTERBANCARIAS
    for each row
    when (NEW.ID_INTERBANCARIA IS NULL)
BEGIN
    :NEW.ID_INTERBANCARIA := seq_transacciones_interbancarias.NEXTVAL;
END;
/

